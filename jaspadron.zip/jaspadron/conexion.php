<?php
// conexion.php

$host = getenv('DB_HOST') ?: "sql107.ezyro.com"; // Cambia si es necesario
$user = getenv('DB_USER') ?: "ezyro_40914543"; // Cambia si es necesario
$pass = getenv('DB_PASS') ?: "1ff252ed"; // Cambia si es necesario
$db = getenv('DB_NAME') ?: "ezyro_40914543_votantes"; // El nombre de tu base de datos
$port = getenv('DB_PORT') ?: "3306";
    
/*$host = "sql202.infinityfree.com"; // Cambia si es necesario
$user = "if0_38789798"; // Cambia si es necesario
$pass = "vMiZOWp4pswF"; // Cambia si es necesario
$db = "if0_38789798_reg_votantes"; // El nombre de tu base de datos
$port = "3306";*/

$conn = new mysqli($host, $user, $pass, $db,$port);

if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}
$conn->set_charset("utf8mb4");
?>
