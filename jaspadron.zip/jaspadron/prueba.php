<?php   

$host = 'pg-10a1fb6b-jperez-e3a9.d.aivencloud.com'; // O 'localhost' si están en el mismo servidor
$port = '10498';
$dbname = 'defaultdb';
$user = 'avnadmin';
$password = 'AVNS_tSZcSIwV-J-UQ__rODc';

if (!function_exists('pg_connect')) {
    die('PostgreSQL NO está habilitado en este servidor');
}

/*$conn_string = "host=$host port=$port dbname=$dbname user=$user password=$password";
$conn = pg_connect($conn_string);

if ($conn) {
    echo "¡Conexión exitosa a PostgreSQL!";
    // Aquí puedes ejecutar tus consultas
    pg_close($conn); // Cierra la conexión
} else {
    echo "Error al conectar a PostgreSQL: " . pg_last_error();
}*/
?>