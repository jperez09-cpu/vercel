<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

ob_start();
require 'conexion.php';
session_start();

if (!isset($_SESSION['usuario_id'])) {
    header('Location: login.php');
    exit;
}

$usuario_id = $_SESSION['usuario_id'];
$rol = $_SESSION['rol'] ?? 'user';

// Filtros
$buscar = $_GET['buscar'] ?? '';
$f_usuario = $_GET['f_usuario'] ?? '';
$f_concejal = $_GET['f_concejal'] ?? '';

// Headers CSV para Excel
header('Content-Type: text/csv; charset=UTF-8');
header('Content-Disposition: attachment; filename="reporte_votantes.csv"');
echo "\xEF\xBB\xBF"; // BOM UTF-8 para acentos

$output = fopen('php://output', 'w');
$delimiter = ';';

// Encabezados
fputcsv($output, ['Nombre','Apellido','Cédula','Teléfono','Barrio','Zona','Dirigente','Concejal','Fecha Registro'], $delimiter);

// Construcción dinámica del WHERE
$where = [];
$params = [];
$tipos = "";

// Filtro búsqueda
$where[] = "(v.nombre LIKE ? OR v.cedula LIKE ?)";
$params[] = "%$buscar%";
$params[] = "%$buscar%";
$tipos .= "ss";

// Filtro por rol
if ($rol === 'user') {
    $where[] = "v.id_usuario = ?";
    $params[] = $usuario_id;
    $tipos .= "i";
} elseif ($rol === 'concejal') {
    // Obtener id del concejal logueado
    $stmtCon = $conn->prepare("SELECT id FROM concejales WHERE nro_cedula = ?");
    $stmtCon->bind_param("s", $_SESSION['usuario']);
    $stmtCon->execute();
    $resCon = $stmtCon->get_result()->fetch_assoc();
    $id_concejal = $resCon['id'] ?? 0;

    $where[] = "v.id_concejal = ?";
    $params[] = $id_concejal;
    $tipos .= "i";

    if ($f_usuario !== '' && is_numeric($f_usuario)) {
        $where[] = "v.id_usuario = ?";
        $params[] = (int)$f_usuario;
        $tipos .= "i";
    }
} elseif ($rol === 'admin') {
    if ($f_concejal !== '' && is_numeric($f_concejal)) {
        $where[] = "v.id_concejal = ?";
        $params[] = (int)$f_concejal;
        $tipos .= "i";
    }
    if ($f_usuario !== '' && is_numeric($f_usuario)) {
        $where[] = "v.id_usuario = ?";
        $params[] = (int)$f_usuario;
        $tipos .= "i";
    }
}

// SQL principal
$sql = "
SELECT
v.nombre,
v.apellido,
v.cedula,
v.telefono,
b.descripcion AS barrio,
v.zona,
u.nombre_completo AS usuario,
c.nombre AS concejal,
v.fecha_registro
FROM votantes v
LEFT JOIN barrios b ON b.id_barrios = v.id_barrios
LEFT JOIN usuarios u ON u.id = v.id_usuario
LEFT JOIN concejales c ON c.id = v.id_concejal
";

if (count($where) > 0) {
    $sql .= " WHERE " . implode(" AND ", $where);
}

$sql .= " ORDER BY v.id DESC";

$stmt = $conn->prepare($sql);
if (!empty($params)) {
    $stmt->bind_param($tipos, ...$params);
}
$stmt->execute();
$result = $stmt->get_result();

// Escribir filas CSV
$total = 0;
while ($row = $result->fetch_assoc()) {
    fputcsv($output, [
        $row['nombre'],
        $row['apellido'],
        $row['cedula'],
        $row['telefono'],
        $row['barrio'],
        $row['zona'],
        $row['usuario'],
        $row['concejal'],
        $row['fecha_registro']
    ], $delimiter);
    $total++;
}

// Total al final
fputcsv($output, [], $delimiter);
fputcsv($output, ['TOTAL DE VOTANTES', $total], $delimiter);

fclose($output);
exit;
?>